import sys
from conf import settings
from log import create_logger
logger = create_logger.logger()
from core import register
from core import file_info
from core import add_black

def login():
    vip_file_path = settings.BASE_DIR + "\\db\\vip_info.json"
    vips_info = file_info.file_info(vip_file_path)
    # print("VIP客户信息--->",vips_info)        #{'xiong': 'xr112358', 'wang': '_12345678', 'xiaoming': 'asdf123456'}
    blackList_file_path = settings.BASE_DIR + "\\db\\blackList.json"
    blackList_info = file_info.file_info(blackList_file_path)
    # print("黑名单--->",blackList_info)   #["oldwang","oldsong"]
    print("###############欢迎来到登录注册界面#################")
    new_name = input("请输入用户名>>>")
    if new_name in blackList_info:
        raise ValueError('###你被加入黑名单了,请联系管理员！###')
    elif new_name not in vips_info.keys():
        print('###你还不是VIP客户，请注册！###')
        print('###输入 1：进入注册系统，输入 0：退出系统###')
        choice = input("请选择（1/0?）>>>>")
        if isinstance(int(choice),int) and int(choice) == 1:
            register.register(new_name,vip_file_path)
        else:
            sys.exit('不注册用户直接退出系统！')
    else:
        count = 0
        print("###输入您的VIP密码，出错次数超过3次系统锁定！###")
        while count<3:
            pwd = input('输入您的VIP密码>>>')
            if pwd == vips_info[new_name]:
                count +=1
                logger.info("恭喜%s进入系统！" % new_name)
                import webbrowser
                webbrowser.open("http://www.baidu.com")
                sys.exit('恭喜%s，进入系统！'%new_name)
            else:
                count += 1
                print('密码错误请重新输入，您已经输入%s次！'%(count))
        else:
            add_black.add_black(new_name,blackList_file_path)
            logger.error("%s的密码连续输错3次，账户被锁定！"%new_name)
            sys.exit("密码连续输错3次，账户被锁定！")

def run():
    login()




