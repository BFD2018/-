import re,json,sys
from core import main
logger = main.logger

def register(username,path):
    count = 0
    print("###注意：密码不能以数字开头包含数字/字母/下划线的8位字符！###")
    while count<3:
        pwd = input("请输入密码>>>")
        pwd_auth = re.match(r'[a-zA-Z_]{1}[0-9a-zA-Z_]{7}',pwd)
        if pwd_auth:
            count += 1
            with open(path, 'r', encoding='utf8') as f:
                data = f.read()
                dic = json.loads(data)

            with open(path, 'w', encoding='utf8') as f:
                dic[username] = pwd
                info = json.dumps(dic)
                f.write(info)
                logger.info(info)
            return main.login()
        else:
            count += 1
            print("密码输入格式错误，请重新输入！")
    logger.warning('###密码输入超过3次，系统被锁定！###')
    sys.exit('###密码输入超过3次，系统被锁定！###')