import json
from core import main
logger = main.logger

def add_black(username,path):
    with open(path, 'r', encoding='utf-8') as f:
        data = f.read()
        dic = json.loads(data)
    with open(path, 'w', encoding='utf-8') as f:
        dic.append(username)
        info = json.dumps(dic)
        f.write(info)
        logger.info("debug：恭喜%s进入系统！" % username)
    logger.warning('%s已加入黑名单'%username)
    return '%s已加入黑名单'%username