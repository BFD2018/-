import json

def file_info(filename):
    fileType = filename.split("\\")[-1]
    # print(fileType)
    if  fileType == 'vip_info.json':
        with open(filename,'r') as f:
            data = json.loads(f.read())
        return data

    elif fileType == 'blackList.json':
        with open(filename,'r',encoding='utf8') as f:
            data = f.read()
        return data