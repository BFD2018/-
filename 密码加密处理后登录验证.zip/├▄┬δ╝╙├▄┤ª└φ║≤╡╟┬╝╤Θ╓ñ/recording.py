__author__ = 'Justin Xiong'

import hmac

class User(object):
    def __init__(self, username, password,filepath='loginData'):
        self.username = username
        self.key = 'xiong'
        self.password = self.hmac_md5(self.key, password)        #self.key, password 传入的都是字符串
        self.saveInfo = self.saveInfo(filepath)

    def hmac_md5(self,key, message):
        return hmac.new(key.encode('utf-8'), message.encode('utf-8'), 'MD5').hexdigest()

    def saveInfo(self,filepath):
        userInfo = self.username + "\t\t" + self.password + "\n"
        with open(filepath,'a+',encoding='utf-8') as f:
            f.write(userInfo)
        return  userInfo.split()


if __name__ == '__main__':
    name_pwd = {'michael':'123456',
                'bob': 'abc999',
                'alice': 'alice2008'
                }
    for key,value in name_pwd.items():
        user = User(key, value)
        print(user.saveInfo)

